// File to be used by a theme. Calling automatically to theme.init function when everything is loaded (if exists):
// var theme = {};
// theme.init = function () {  alert("Hello theme"); }; 