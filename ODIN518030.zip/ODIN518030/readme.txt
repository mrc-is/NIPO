5.18.0.30
Fix bug: Code after *IF sometimes not executed (issue 3206)
Change: Add support for STRREPLACE
Change: Add support for question/code ids.
Change: Write floating point numbers with 1 digit more precision.
Change: Accept no control type for control on repeat, do not show missing categories
Fix bug: *ENDPAGE saved differently as nfield (issue 3188)

5.18.0.29
Change: Add support for *USEBUTTONS/?BUTTON
Change: Add support for datetime functions
Change: Add support for function aliases with '?'
Fix bug: Check fails for question that shows and saves in the same variable (issue 3163)
Fix bug: No font accepted in *PUT x "text with *FONT" after category (issue 3177)
Changed rewriting of the questionnaire:
Write functions with a '?' when checking for Nfield is selected.
Write functions without a '?' (if that name exists) when checking for Nfield is NOT selected.

5.18.0.28
Change: Add LOOPVAR=name in var comment in diana export, name = variable name to be used in DSC loops.

5.18.0.27
Change: Always parse with native parser for fix/unfix/renumber/remove commands
Fix bug: Setting language 'English' always selects default language (issue 3073)
Fix bug: Executing *GETDATA in testing cati client crashes odin developer.
Fix bug: Language with RTL or LTR not set correctly (issue 3069).
Fix bug: Add extra line when re-writing script with comment on question line and parsing with managed parser. (issue 3082)

5.18.0.26
Change: Parse *ENDPAGE
Change: Parse and execute *USELIST new style, and corresponding Property function in expression
Fix bug: Control not used when checking variable values set in repeat loop (issue 3042)

5.18.0.25
Change:
  files removed: cpprest142_2_10.dll, DomainCpp.dll
  file added: ManagedExtensions\Newtonsoft.Json.dll
Fix bug: Indentation added when breaking a string to fit on a new line (issue 3009) (indentation removed in that case)
Fix bug: Corrected some error messages when using Nfield parser and fragment.
Fix bug: Crash when using Ctrl + F when file opened as datafile (issue 3010)
Change: Use ManagedExtensions for Nfield communication (Nfield preview)
Change: When parsing, show which parser is being used (Nfield or NFS)
Change: Also show 'using unfixed positions' when using a fragment with unfixed position that holds question(s)

5.18.0.24
Running the Nfield check will now use the managed parser to check questionnaire

5.18.0.23
Fix bug: When not exporting variables with 'null filters' only filters that could be exported in the var file were inspected (issue 2983)

5.18.0.22
Fix bug: Crash possible in check or export when using dynamic lists.
Change: For open categories write comment CnOPEN=X to be able to always create helper field in DSC (issue 2943).

5.18.0.21
Change: For undefined variables use latest value in text/numbers that are not displayed to improve exports.
        (Like list references)

5.18.0.20
Change: Write order and random variables differently in var file to save space.
Fix bug: Parser could get into undefined state when reading an unexpected number, could crash (issue 2861)
Fix bug: While checking variables not 'undefined' after *GETDATA (another cause for issue 2823)
Fix bug: Parsing and checking uselist with variables in id can fail (issue 2859)
Change: now using "cpprest142_2_10.dll" , was "cpprest141_2_10.dll", and latest C++ runtimes
(latest runtimes in Software\VC_Redist\VS2022)
Change: Added possibility for not expanding 'loop' variables.
Fix bug: When checking and using *PUT X "*?Y" and var Y is 'undefined', var X was 'defined' (cause for issue 2823)
Change: Warning on using *TEMPLATE, *UIOPTIONS and *UIRENDER in INIT block.
Change: ?JSON implemented
Change: *REQUEST implemented (Developer brings up dialog for pasting result when running for CATI)
Change: when using a range as a value, use the first value of the range and not 0. (as Nfield does)
Change: issue an error when trying to store something in a spot that cannot hold data.
(Like a question without a position)
Change: issue an error when the 'S' operator is applied to a question that is not inside a matrix or repetition block.
Change: Grid and Table properties are written in var file.

5.18.0.19
Fix bug: Variables for questions '*QUESTION x *MULTI pos n' were not written correctly in the exports (issue 2137)
Fix bug: Open answer for questions '*QUESTION x *MULTI pos n' were not written correctly (issue 2341)

5.18.0.18
Change: Include questions in subroutines in table when called from repeat with *TABLE command.
Change: Use *UIOPTIONS "position=Text Cat 1|Text Cat 2|Text Cat 3" for scale question codes
        (to be compatible with the nfield version).
Change: Order variables on repeat are now named: REPnnn_xx (nnn = repeat number, xx = order in repeat) (was REPnnn_xx_1)
Change: Variables for questions '*QUESTION x *MULTI pos n' are now ordered normally in the export to DIANA
        The ordering was strange for questions inside subroutines
Fix bug: Variables for questions '*QUESTION x *MULTI pos n' might not be written with the correct length in the export to DIANA
         They were written with the length of the largest code.

5.18.0.17
Change: Check for Nfield, do not accept *SAVE in List (issue 1910)
Fix bug: When reporting duplicate position is suppressed, duplicate multiple positions are still reported (issue 1864)

5.18.0.16
Change: Allow *UIOPTIONS to have global scope
Fix bug: Checking a questionnaire does report no error, but creating export does (issue 1787)
Change: Show error in creating datamap in export.
Fix bug: Unknown error when storing random order on form question (issue 1535)
Change: Accept *SHOWDOCUMENT in BLOCK and MATRIX on question line.
Change: Max SPSS value label length increased to 200 (issue 1754).

5.18.0.15
Fix bug: Check produces unknown error with array in random repeat loop (issue 1528)

5.18.0.14
Change: *GETLFQLIST implemented (Developer brings up dialog for entering levels when running for CATI)
Fix bug: Slow checking of large random repeat (issue 1462).
Fix bug: ODIN Developer removes array dimensions while fixing/unfixing questionnaire (issue 1490)

5.18.0.13

Change: Check for Nfield, auto create variable now fatal (issue 1389).
Fix bug: No error for putting too high code in multi question (issue 1451) (now reports error).
Fix bug: *VAR followed by command results in wrong quick code (issue 1150) (now reports error).
Fix bug: Question number 0 is accepted (issue 1015) (not accepted any more).

5.18.0.12

Fix bug: Question preview does not work.

5.18.0.11

Fix bug: When use group rotate, groups were randomized
Fix bug: When using the S operator on a question inside a matrix that was skipped an error was generated.
Change: Check for Nfield, direct reference to position and using variable 0-9 now fatal.
Change: Warning added for used questions that are sharing positions (for NFS only when data is put into them)

5.18.0.10

Fix bug: Only first iteration of BLOCK in REPEAT exported to VAR file.
Fix bug: When ordering the codes of a question with a source that contains more items then the question has codes
         the resulting order might be wrong.
Fix bug: Double used columns are not reported.
Change: When putting an empty codes or numeric question into a text variable, the text variable is empty (it used to become: "0")
